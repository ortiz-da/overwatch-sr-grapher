README
==================================================================
This python script was designed to help visualize a player's skill ranking (SR) in the online multiplayer game, Overwatch. It uses an unofficial api site to pull the player's data, which is then written to a text file. The text file is used to create a graph showing the player's skill over time.

The code has comments to explain most steps of the process.
==================================================================

Notes:
- The script was written in Pycharm and has been tested to run correctly from there using Python 3.9. Simply click run and follow the console prompts.
- There are a few libraries that the script imports:
import datetime
import matplotlib.dates
import mplcursors
from matplotlib import pyplot as plt
import matplotlib.patches as mpatches
from datetime import date
import requests
import json
If you are missing any of these libraries, install them first

==================================================================

Sample input:
Enter your Overwatch Username (Case sensitive):Dortiz
Enter your battletag (just the numbers, no #):1210
Do you want to pull user data for today? (Y/N)n
==================================================================
**Pulling data on this account would currently not provide any useful info. I've included a text and json file to show what the data might look like in an actual use case.
There is also a screenshot titled "graph.png" in this folder that shows what the graph should look like.**