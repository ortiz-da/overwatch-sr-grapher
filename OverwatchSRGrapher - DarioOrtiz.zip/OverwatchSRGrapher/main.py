import datetime
import matplotlib.dates
import mplcursors
from matplotlib import pyplot as plt
# import mplcursors
import matplotlib.patches as mpatches
from datetime import date
import requests
import json
# ----- Ask for the username and battletag------------------------------------------------------------------------------
username = input("Enter your Overwatch Username (Case sensitive):")
battletag = input("Enter your battletag (just the numbers, no #):")
user = username+'-'+battletag
pullTodaysData = input("Do you want to pull user data for today? (Y/N)")
print(user)
# ----------------------------------------------------------------------------------------------------------------------
if pullTodaysData.capitalize() == "Y":
    # ----------------- Send the API request and save the result to a json file --------------------------------------------
    r = requests.get('https://ow-api.com/v1/stats/pc/us/'+user+'/profile')
    data = r.json()
    with open('my-request.json', 'w') as f:
        json.dump(data, f)
    # ----------------------------------------------------------------------------------------------------------------------

    # ----------------- Read json file generated from api request. Extract SR data to a text file. ---------------------
    with open(r'my-request.json') as json_file:
        data = json.load(json_file)
    f = open("statsFile.txt", "a")
    f.write("Date: " + str(date.today()) + "\n")
    for r in data['ratings']:
        f.write(r['role'] + " - ")
        f.write(str(r['level']) + "\n")
    f.write("##########\n")
    f.close()
    # ----------------------------------------------------------------------------------------------------------------

# Graph the SR data using matplotlib
plt.style.use('seaborn')
tankArray = []
dmgArray = []
supportArray = []
allDateArray = []
tankDateArray = []
dmgDateArray = []
supportDateArray = []
# read from the text file
f = open(r'statsFile.txt')
for line in f:
    # Enter SR and date values from each line into arrays. Cast SR values as floats.
    values = line.split()
    if values[0] == "tank":
        tankArray.append(float(values[2]))
    elif values[0] == "damage":
        dmgArray.append(float(values[2]))
    elif values[0] == "support":
        supportArray.append(float(values[2]))
    elif values[0] == "Date:":
        allDateArray.append(values[1])
        tankDateArray.append(values[1])
        dmgDateArray.append(values[1])
        supportDateArray.append(values[1])
# Trim the list of dates for each role so that number of dates and number of data points for each role are equal. This is
# so that you can place on different roles on different dates and the graph still displays properly.
if len(tankArray) < len(tankDateArray):
    while len(tankArray) < len(tankDateArray):
        tankDateArray.pop(0)
if len(dmgArray) < len(dmgDateArray):
    while len(dmgArray) < len(dmgDateArray):
        dmgDateArray.pop(0)
if len(supportArray) < len(supportDateArray):
    while len(supportArray) < len(supportDateArray):
        supportDateArray.pop(0)
# turn the strings from the text file into datetimes
tank_x = [datetime.datetime.strptime(d, "%Y-%m-%d").date() for d in tankDateArray]
dmg_x = [datetime.datetime.strptime(d, "%Y-%m-%d").date() for d in dmgDateArray]
support_x = [datetime.datetime.strptime(d, "%Y-%m-%d").date() for d in supportDateArray]
# Format the x axis
ax = plt.gca()
formatter = matplotlib.dates.DateFormatter("%Y-%m-%d")
ax.xaxis.set_major_formatter(formatter)
plt.xticks(rotation=45)
locator = matplotlib.dates.DayLocator()
ax.xaxis.set_major_locator(locator)
# -------------------------------------------------------------------------
# Plot the tank data
plt.scatter(tank_x, tankArray, c='green', edgecolor='black', linewidth=1)
# Adds lines between points
tankPlot = plt.plot(tank_x, tankArray, c='green')
# Plot the damage data
plt.scatter(dmg_x, dmgArray, c='red', edgecolor='black', linewidth=1)
# Adds lines between points
dmgPlot = plt.plot(dmg_x, dmgArray, c='red')
# Plot the support data
plt.scatter(support_x, supportArray, c='blue', edgecolor='black', linewidth=1)
# Adds lines between points
supportPlot = plt.plot(support_x, supportArray, c='blue')
# -------------------------------------------------------------------------
# Label the graph
plt.title('Overwatch SR Over time')
plt.ylabel('SR')
plt.xlabel('Date')
# Add legend to graph
green_patch = mpatches.Patch(color='green', label='Tank')
red_patch = mpatches.Patch(color='red', label='DPS')
blue_patch = mpatches.Patch(color='blue', label='Support')
plt.legend(handles=[red_patch, green_patch, blue_patch])
# Adds a label when hovering over graph
mplcursors.cursor(hover=True)
plt.tight_layout()
plt.show()